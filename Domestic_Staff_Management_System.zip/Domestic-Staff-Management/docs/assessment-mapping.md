# CO assessment mapping

| CO | Marks | Implementation evidence |
|---|---:|---|
| CO1 | 15 | README ER diagram, normalized relational model, keys, constraints and relationship notes. |
| CO2 | 15 | SQLAlchemy CRUD, relational queries, transactions, indexes, pagination, `database/schema.sql` and SQL examples in README. |
| CO3 | 15 | Flask JSON REST endpoints, HTTP status codes, session authentication, role middleware, validation and pytest coverage. |
| CO4 | 15 | Domain modules for auth, worker/resident, scheduling, access, notifications and anomaly detection; service boundary and architecture diagram in README. |
| CO5 | 20 | Python rule detector, optional Pandas/IsolationForest score, alert persistence, reasons, severity and resolution workflow. |
| CO6 | 20 | Responsive frontend, seeded multi-role demo, executable setup, tests and ten-step manual workflow in README. |
