# API quick test examples

Login first and retain the session cookie:
```http
POST /api/auth/login
Content-Type: application/json
{"email":"admin@demo.local","password":"Admin@123"}
```
Create a worker:
```http
POST /api/workers
Content-Type: application/json
{"full_name":"Demo Person","phone":"9111111111","occupation":"Cook","id_document_type":"Aadhaar (masked)","id_document_last4":"1234"}
```
Approve the worker:
```http
PATCH /api/workers/6/verify
Content-Type: application/json
{"status":"Verified"}
```
Gate entry:
```http
POST /api/access/entry
Content-Type: application/json
{"worker_id":1}
```
Gate exit:
```http
POST /api/access/exit
Content-Type: application/json
{"worker_id":1}
```
Resolve alert:
```http
PATCH /api/anomalies/1/resolve
```
The numeric IDs depend on the current seeded database. All authenticated examples require the cookie returned by login.
