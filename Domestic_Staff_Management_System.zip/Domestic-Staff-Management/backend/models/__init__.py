from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from backend.database import db

class User(db.Model):
    __tablename__='users'
    id=db.Column(db.Integer, primary_key=True)
    name=db.Column(db.String(120), nullable=False)
    email=db.Column(db.String(160), unique=True, nullable=False, index=True)
    password_hash=db.Column(db.String(255), nullable=False)
    role=db.Column(db.String(20), nullable=False, index=True)
    phone=db.Column(db.String(20))
    active=db.Column(db.Boolean, default=True, nullable=False)
    created_at=db.Column(db.DateTime, default=datetime.utcnow)
    def set_password(self,p): self.password_hash=generate_password_hash(p)
    def check_password(self,p): return check_password_hash(self.password_hash,p)
    def public(self): return {'id':self.id,'name':self.name,'email':self.email,'role':self.role,'phone':self.phone}

class Community(db.Model):
    id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(120),nullable=False); address=db.Column(db.String(255))
class Apartment(db.Model):
    id=db.Column(db.Integer,primary_key=True); community_id=db.Column(db.Integer,db.ForeignKey('community.id'),nullable=False); building=db.Column(db.String(30),nullable=False); unit=db.Column(db.String(30),nullable=False)
    __table_args__=(db.UniqueConstraint('community_id','building','unit'),)
class Resident(db.Model):
    id=db.Column(db.Integer,primary_key=True); user_id=db.Column(db.Integer,db.ForeignKey('users.id'),unique=True,nullable=False); apartment_id=db.Column(db.Integer,db.ForeignKey('apartment.id'),nullable=False); household_name=db.Column(db.String(120))
class SecurityGuard(db.Model):
    id=db.Column(db.Integer,primary_key=True); user_id=db.Column(db.Integer,db.ForeignKey('users.id'),unique=True,nullable=False); shift=db.Column(db.String(40))
class Worker(db.Model):
    id=db.Column(db.Integer,primary_key=True); user_id=db.Column(db.Integer,db.ForeignKey('users.id'),unique=True); full_name=db.Column(db.String(120),nullable=False,index=True); phone=db.Column(db.String(20),nullable=False,index=True); address=db.Column(db.String(255)); age=db.Column(db.Integer); occupation=db.Column(db.String(60),nullable=False); emergency_contact=db.Column(db.String(30)); id_document_type=db.Column(db.String(40)); id_document_last4=db.Column(db.String(4)); verification_status=db.Column(db.String(20),default='Pending',nullable=False,index=True); availability=db.Column(db.String(30),default='Available'); created_at=db.Column(db.DateTime,default=datetime.utcnow)
class WorkerAssignment(db.Model):
    id=db.Column(db.Integer,primary_key=True); worker_id=db.Column(db.Integer,db.ForeignKey('worker.id'),nullable=False,index=True); resident_id=db.Column(db.Integer,db.ForeignKey('resident.id'),nullable=False,index=True); apartment_id=db.Column(db.Integer,db.ForeignKey('apartment.id'),nullable=False); start_date=db.Column(db.Date,nullable=False); end_date=db.Column(db.Date); active=db.Column(db.Boolean,default=True)
    __table_args__=(db.UniqueConstraint('worker_id','resident_id','start_date'),)
class Schedule(db.Model):
    id=db.Column(db.Integer,primary_key=True); assignment_id=db.Column(db.Integer,db.ForeignKey('worker_assignment.id'),nullable=False,index=True); weekday=db.Column(db.Integer,nullable=False); start_time=db.Column(db.String(5),nullable=False); end_time=db.Column(db.String(5),nullable=False); valid_from=db.Column(db.Date,nullable=False); valid_until=db.Column(db.Date); active=db.Column(db.Boolean,default=True)
class Attendance(db.Model):
    id=db.Column(db.Integer,primary_key=True); worker_id=db.Column(db.Integer,db.ForeignKey('worker.id'),nullable=False,index=True); resident_id=db.Column(db.Integer,db.ForeignKey('resident.id'),nullable=False); guard_id=db.Column(db.Integer,db.ForeignKey('security_guard.id')); check_in=db.Column(db.DateTime,nullable=False,default=datetime.utcnow); check_out=db.Column(db.DateTime); status=db.Column(db.String(20),default='Present')
class EntryExitLog(db.Model):
    id=db.Column(db.Integer,primary_key=True); worker_id=db.Column(db.Integer,db.ForeignKey('worker.id'),nullable=False,index=True); resident_id=db.Column(db.Integer,db.ForeignKey('resident.id')); guard_id=db.Column(db.Integer,db.ForeignKey('security_guard.id')); community_id=db.Column(db.Integer,db.ForeignKey('community.id')); event_type=db.Column(db.String(10),nullable=False); event_time=db.Column(db.DateTime,default=datetime.utcnow,nullable=False,index=True); authorized=db.Column(db.Boolean,default=False); reason=db.Column(db.String(255))
class VerificationDocument(db.Model):
    id=db.Column(db.Integer,primary_key=True); worker_id=db.Column(db.Integer,db.ForeignKey('worker.id'),nullable=False,index=True); document_type=db.Column(db.String(40),nullable=False); filename=db.Column(db.String(255)); status=db.Column(db.String(20),default='Pending'); reviewed_by=db.Column(db.Integer,db.ForeignKey('users.id')); reviewed_at=db.Column(db.DateTime); notes=db.Column(db.String(255)); created_at=db.Column(db.DateTime,default=datetime.utcnow)
class Notification(db.Model):
    id=db.Column(db.Integer,primary_key=True); user_id=db.Column(db.Integer,db.ForeignKey('users.id'),nullable=False,index=True); message=db.Column(db.String(255),nullable=False); read=db.Column(db.Boolean,default=False); created_at=db.Column(db.DateTime,default=datetime.utcnow)
class AccessRequest(db.Model):
    id=db.Column(db.Integer,primary_key=True); worker_id=db.Column(db.Integer,db.ForeignKey('worker.id'),nullable=False); resident_id=db.Column(db.Integer,db.ForeignKey('resident.id'),nullable=False); request_type=db.Column(db.String(20),default='Temporary'); valid_from=db.Column(db.DateTime,nullable=False); valid_until=db.Column(db.DateTime); status=db.Column(db.String(20),default='Pending'); created_at=db.Column(db.DateTime,default=datetime.utcnow)
class AnomalyAlert(db.Model):
    id=db.Column(db.Integer,primary_key=True); worker_id=db.Column(db.Integer,db.ForeignKey('worker.id')); log_id=db.Column(db.Integer,db.ForeignKey('entry_exit_log.id')); anomaly_type=db.Column(db.String(60),nullable=False); severity=db.Column(db.String(20),nullable=False); score=db.Column(db.Float,default=0); reason=db.Column(db.String(500),nullable=False); resolved=db.Column(db.Boolean,default=False); created_at=db.Column(db.DateTime,default=datetime.utcnow,index=True)
