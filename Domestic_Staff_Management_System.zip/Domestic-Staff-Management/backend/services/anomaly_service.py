from anomaly_detection.detector import detect_event
from backend.database import db
from backend.models import AnomalyAlert, Worker, EntryExitLog, WorkerAssignment

def analyze_log(log, recent_failures=0):
    worker=Worker.query.get(log.worker_id)
    # Determine whether the most recent prior gate event left the worker inside.
    previous=EntryExitLog.query.filter(EntryExitLog.worker_id==log.worker_id, EntryExitLog.id < log.id).order_by(EntryExitLog.id.desc()).first()
    open_entries=1 if previous and previous.event_type=='ENTRY' else 0
    assigned=WorkerAssignment.query.filter_by(worker_id=log.worker_id,active=True).first() is not None
    event={'event_type':log.event_type,'event_time':log.event_time,'authorized':log.authorized}
    findings=detect_event(event,worker,open_entries,recent_failures,assigned=assigned)
    for item in findings:
        db.session.add(AnomalyAlert(worker_id=log.worker_id,log_id=log.id,anomaly_type=item['type'],severity=item['severity'],score=item['score'],reason=item['reason']))
    return findings
