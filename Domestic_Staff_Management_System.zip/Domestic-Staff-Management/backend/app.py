from datetime import datetime, date, time, timedelta
from functools import wraps
from flask import Flask, request, jsonify, session, send_from_directory
from sqlalchemy import func, or_
from backend.config import Config
from backend.database import db
from backend.models import *
from backend.services.anomaly_service import analyze_log

ROLES={'admin','resident','guard','worker'}
def create_app(test_config=None):
    app=Flask(__name__,static_folder='../frontend',static_url_path='/static'); app.config.from_object(Config)
    if test_config: app.config.update(test_config)
    db.init_app(app)
    with app.app_context(): db.create_all()
    def current_user(): return User.query.get(session.get('user_id')) if session.get('user_id') else None
    def auth_required(*roles):
        def deco(fn):
            @wraps(fn)
            def wrapped(*a,**kw):
                u=current_user()
                if not u or not u.active: return jsonify(error='Authentication required'),401
                if roles and u.role not in roles: return jsonify(error='Insufficient permissions'),403
                return fn(*a,**kw)
            return wrapped
        return deco
    def fail(message,status=400): return jsonify(error=message),status
    def notify(user_id,message): db.session.add(Notification(user_id=user_id,message=message))
    @app.get('/')
    def home(): return send_from_directory(app.static_folder,'index.html')
    @app.get('/api/health')
    def health(): return jsonify(status='ok',service='domestic-staff-management')
    @app.post('/api/auth/register')
    def register():
        d=request.get_json(silent=True) or {}; role=d.get('role','resident')
        if role not in ('resident','worker'): return fail('Self-registration is limited to resident or worker accounts')
        if not d.get('name') or not d.get('email') or len(d.get('password',''))<8: return fail('Name, email and password (8+ characters) are required')
        if User.query.filter_by(email=d['email'].lower()).first(): return fail('Email already registered',409)
        u=User(name=d['name'].strip(),email=d['email'].lower(),role=role,phone=d.get('phone')); u.set_password(d['password']); db.session.add(u); db.session.flush()
        if role=='worker':
            w=Worker(user_id=u.id,full_name=u.name,phone=u.phone or '',occupation=d.get('occupation','Other')); db.session.add(w)
        else:
            apt=Apartment.query.first()
            if not apt: return fail('Community apartments are not initialized',503)
            db.session.add(Resident(user_id=u.id,apartment_id=apt.id))
        db.session.commit(); return jsonify(message='Registration submitted',user=u.public()),201
    @app.post('/api/auth/login')
    def login():
        d=request.get_json(silent=True) or {}; u=User.query.filter_by(email=(d.get('email') or '').lower()).first()
        if not u or not u.check_password(d.get('password','')): return fail('Invalid email or password',401)
        session.clear(); session['user_id']=u.id; return jsonify(user=u.public())
    @app.post('/api/auth/logout')
    def logout(): session.clear(); return jsonify(message='Logged out')
    @app.get('/api/auth/me')
    @auth_required()
    def me(): return jsonify(user=current_user().public())
    @app.get('/api/dashboard')
    @auth_required()
    def dashboard():
        u=current_user(); today=date.today(); data={'user':u.public()}
        if u.role=='admin':
            data.update(total_workers=Worker.query.count(),total_residents=Resident.query.count(),verified=Worker.query.filter_by(verification_status='Verified').count(),pending=Worker.query.filter_by(verification_status='Pending').count(),inside=EntryExitLog.query.filter_by(event_type='ENTRY').count()-EntryExitLog.query.filter_by(event_type='EXIT').count(),today_attendance=Attendance.query.filter(func.date(Attendance.check_in)==today).count(),alerts=AnomalyAlert.query.filter_by(resolved=False).count())
        elif u.role=='resident':
            r=Resident.query.filter_by(user_id=u.id).first(); data['resident_id']=r.id if r else None; data['assignments']=[{'id':a.id,'worker':Worker.query.get(a.worker_id).full_name,'occupation':Worker.query.get(a.worker_id).occupation} for a in WorkerAssignment.query.filter_by(resident_id=r.id,active=True)] if r else []
        elif u.role=='guard': data['expected_workers']=Worker.query.filter_by(verification_status='Verified').count()
        else:
            w=Worker.query.filter_by(user_id=u.id).first(); data['worker_id']=w.id if w else None; data['verification_status']=w.verification_status if w else None
        return jsonify(data)
    @app.get('/api/workers')
    @auth_required('admin','resident','guard')
    def workers():
        q=Worker.query
        if current_user().role=='resident':
            r=Resident.query.filter_by(user_id=current_user().id).first(); ids=[a.worker_id for a in WorkerAssignment.query.filter_by(resident_id=r.id,active=True)] if r else []; q=q.filter(Worker.id.in_(ids))
        search=request.args.get('q','').strip()
        if search: q=q.filter(or_(Worker.full_name.ilike(f'%{search}%'),Worker.phone.ilike(f'%{search}%'),Worker.occupation.ilike(f'%{search}%')))
        status=request.args.get('status')
        if status: q=q.filter_by(verification_status=status)
        page=max(1,request.args.get('page',1,type=int)); items=q.order_by(Worker.full_name).paginate(page=page,per_page=min(100,max(1,request.args.get('per_page',20,type=int))),error_out=False)
        return jsonify(items=[worker_json(w) for w in items.items],page=page,pages=items.pages,total=items.total)
    def worker_json(w): return {'id':w.id,'name':w.full_name,'phone':w.phone,'occupation':w.occupation,'age':w.age,'verification_status':w.verification_status,'availability':w.availability,'address':w.address,'id_document_type':w.id_document_type,'id_document_last4':w.id_document_last4}
    @app.post('/api/workers')
    @auth_required('admin','resident')
    def add_worker():
        d=request.get_json(silent=True) or {}
        if not d.get('full_name') or not d.get('phone') or not d.get('occupation'): return fail('full_name, phone and occupation are required')
        w=Worker(full_name=d['full_name'].strip(),phone=d['phone'],occupation=d['occupation'],age=d.get('age'),address=d.get('address'),emergency_contact=d.get('emergency_contact'),id_document_type=d.get('id_document_type'),id_document_last4=(d.get('id_document_last4') or '')[-4:]); db.session.add(w); db.session.flush(); db.session.add(VerificationDocument(worker_id=w.id,document_type=w.id_document_type or 'Identity')); db.session.commit(); return jsonify(worker=worker_json(w)),201
    @app.get('/api/workers/<int:wid>')
    @auth_required('admin','resident','guard','worker')
    def get_worker(wid):
        w=Worker.query.get_or_404(wid)
        if current_user().role=='worker' and w.user_id!=current_user().id: return fail('Forbidden',403)
        return jsonify(worker=worker_json(w))
    @app.put('/api/workers/<int:wid>')
    @auth_required('admin')
    def update_worker(wid):
        w=Worker.query.get_or_404(wid); d=request.get_json(silent=True) or {}
        for key in ('full_name','phone','occupation','address','emergency_contact','availability','age'):
            if key in d: setattr(w,key,d[key])
        db.session.commit(); return jsonify(worker=worker_json(w))
    @app.delete('/api/workers/<int:wid>')
    @auth_required('admin')
    def delete_worker(wid):
        w=Worker.query.get_or_404(wid); w.availability='Inactive'
        for a in WorkerAssignment.query.filter_by(worker_id=wid): a.active=False
        db.session.commit(); return jsonify(message='Worker deactivated; historical records retained')
    @app.patch('/api/workers/<int:wid>/verify')
    @auth_required('admin')
    def verify_worker(wid):
        w=Worker.query.get_or_404(wid); d=request.get_json(silent=True) or {}; status=d.get('status')
        if status not in ('Verified','Rejected','Pending'): return fail('status must be Verified, Rejected or Pending')
        w.verification_status=status; doc=VerificationDocument.query.filter_by(worker_id=wid).order_by(VerificationDocument.id.desc()).first()
        if doc: doc.status=status; doc.reviewed_by=current_user().id; doc.reviewed_at=datetime.utcnow(); doc.notes=d.get('notes')
        db.session.commit(); return jsonify(worker=worker_json(w))
    @app.get('/api/residents')
    @auth_required('admin')
    def residents():
        rows=db.session.query(Resident,User,Apartment).join(User,Resident.user_id==User.id).join(Apartment,Resident.apartment_id==Apartment.id).all()
        return jsonify(items=[{'id':r.id,'name':u.name,'email':u.email,'building':a.building,'unit':a.unit} for r,u,a in rows])
    @app.post('/api/residents')
    @auth_required('admin')
    def add_resident():
        d=request.get_json(silent=True) or {}; apt=Apartment.query.get(d.get('apartment_id'))
        if not apt or not d.get('name') or not d.get('email'): return fail('Valid apartment, name and email required')
        if User.query.filter_by(email=d['email'].lower()).first(): return fail('Email already exists',409)
        u=User(name=d['name'],email=d['email'].lower(),role='resident'); u.set_password(d.get('password','ChangeMe123!')); db.session.add(u); db.session.flush(); r=Resident(user_id=u.id,apartment_id=apt.id); db.session.add(r); db.session.commit(); return jsonify(id=r.id),201
    @app.put('/api/residents/<int:rid>')
    @auth_required('admin')
    def update_resident(rid):
        r=Resident.query.get_or_404(rid); d=request.get_json(silent=True) or {}
        if 'apartment_id' in d: r.apartment_id=d['apartment_id']
        if 'household_name' in d: r.household_name=d['household_name']
        db.session.commit(); return jsonify(message='Resident updated')
    @app.delete('/api/residents/<int:rid>')
    @auth_required('admin')
    def delete_resident(rid):
        r=Resident.query.get_or_404(rid); u=User.query.get(r.user_id); u.active=False; db.session.commit(); return jsonify(message='Resident deactivated')
    @app.post('/api/assignments')
    @auth_required('admin','resident')
    def assign_worker():
        d=request.get_json(silent=True) or {}; r=Resident.query.filter_by(user_id=current_user().id).first() if current_user().role=='resident' else Resident.query.get(d.get('resident_id'))
        w=Worker.query.get(d.get('worker_id'))
        if not r or not w: return fail('Resident and worker must exist')
        apt=Apartment.query.get(r.apartment_id); a=WorkerAssignment(worker_id=w.id,resident_id=r.id,apartment_id=apt.id,start_date=date.today()); db.session.add(a); db.session.commit(); return jsonify(id=a.id),201
    @app.get('/api/schedules')
    @auth_required()
    def schedules():
        q=Schedule.query.order_by(Schedule.weekday,Schedule.start_time)
        return jsonify(items=[{'id':s.id,'assignment_id':s.assignment_id,'weekday':s.weekday,'start_time':s.start_time,'end_time':s.end_time,'active':s.active} for s in q.all()])
    @app.post('/api/schedules')
    @auth_required('admin','resident')
    def create_schedule():
        d=request.get_json(silent=True) or {}; a=WorkerAssignment.query.get(d.get('assignment_id'))
        if not a or not d.get('start_time') or not d.get('end_time'): return fail('Valid assignment and times required')
        if d['start_time']>=d['end_time']: return fail('End time must be after start time')
        conflict=Schedule.query.filter_by(assignment_id=a.id,weekday=d.get('weekday',date.today().weekday()),active=True).filter(Schedule.start_time<d['end_time'],Schedule.end_time>d['start_time']).first()
        if conflict: return fail('Schedule conflicts with an existing schedule',409)
        s=Schedule(assignment_id=a.id,weekday=d.get('weekday',date.today().weekday()),start_time=d['start_time'],end_time=d['end_time'],valid_from=date.today()); db.session.add(s); db.session.commit(); return jsonify(id=s.id),201
    @app.put('/api/schedules/<int:sid>')
    @auth_required('admin','resident')
    def update_schedule(sid):
        s=Schedule.query.get_or_404(sid); d=request.get_json(silent=True) or {}; s.start_time=d.get('start_time',s.start_time); s.end_time=d.get('end_time',s.end_time); s.active=d.get('active',s.active); db.session.commit(); return jsonify(message='Schedule updated')
    @app.delete('/api/schedules/<int:sid>')
    @auth_required('admin','resident')
    def delete_schedule(sid):
        s=Schedule.query.get_or_404(sid); s.active=False; db.session.commit(); return jsonify(message='Schedule cancelled')
    def log_access(d,event_type):
        wid=d.get('worker_id'); w=Worker.query.get(wid) if wid else None
        if not w: return None,fail('Worker not found',404)
        assignment=WorkerAssignment.query.filter_by(worker_id=wid,active=True).first(); resident_id=d.get('resident_id') or (assignment.resident_id if assignment else None)
        authorized=w.verification_status=='Verified' and assignment is not None
        guard=SecurityGuard.query.filter_by(user_id=current_user().id).first() if current_user().role=='guard' else None
        if event_type=='ENTRY' and EntryExitLog.query.filter_by(worker_id=wid,event_type='ENTRY').order_by(EntryExitLog.id.desc()).first() and not EntryExitLog.query.filter_by(worker_id=wid,event_type='EXIT').filter(EntryExitLog.id>EntryExitLog.query.filter_by(worker_id=wid,event_type='ENTRY').order_by(EntryExitLog.id.desc()).first().id).first():
            authorized=False
        log=EntryExitLog(worker_id=wid,resident_id=resident_id,guard_id=guard.id if guard else None,event_type=event_type,authorized=authorized,reason=d.get('reason'))
        db.session.add(log); db.session.flush(); analyze_log(log); db.session.add(Attendance(worker_id=wid,resident_id=resident_id,guard_id=guard.id if guard else None,check_in=log.event_time) if event_type=='ENTRY' and authorized else Notification(user_id=Resident.query.get(resident_id).user_id,message=f'{w.full_name} {event_type.lower()} recorded') if resident_id and Resident.query.get(resident_id) else Notification(user_id=current_user().id,message=f'Access attempt for {w.full_name} recorded'))
        if event_type=='EXIT':
            att=Attendance.query.filter_by(worker_id=wid,check_out=None).order_by(Attendance.id.desc()).first()
            if att: att.check_out=log.event_time
        db.session.commit(); return log,None
    @app.post('/api/access/entry')
    @auth_required('admin','guard')
    def entry():
        d=request.get_json(silent=True) or {}; log,error=log_access(d,'ENTRY'); return error if error else (jsonify(id=log.id,authorized=log.authorized,event_time=log.event_time.isoformat()),201)
    @app.post('/api/access/exit')
    @auth_required('admin','guard')
    def exit_access():
        d=request.get_json(silent=True) or {}; log,error=log_access(d,'EXIT'); return error if error else (jsonify(id=log.id,authorized=log.authorized,event_time=log.event_time.isoformat()),201)
    @app.get('/api/access/logs')
    @auth_required('admin','guard','resident')
    def logs():
        q=EntryExitLog.query.order_by(EntryExitLog.event_time.desc()).limit(100); return jsonify(items=[{'id':x.id,'worker':Worker.query.get(x.worker_id).full_name,'type':x.event_type,'time':x.event_time.isoformat(),'authorized':x.authorized,'reason':x.reason} for x in q.all()])
    @app.get('/api/access/currently-inside')
    @auth_required('admin','guard')
    def inside():
        latest={}
        for x in EntryExitLog.query.order_by(EntryExitLog.event_time).all(): latest[x.worker_id]=x
        ids=[wid for wid,x in latest.items() if x.event_type=='ENTRY']; return jsonify(items=[worker_json(Worker.query.get(i)) for i in ids if Worker.query.get(i)])
    @app.get('/api/attendance/history')
    @auth_required('admin','resident','worker')
    def attendance():
        q=Attendance.query.order_by(Attendance.check_in.desc()).limit(100)
        if current_user().role=='worker':
            w=Worker.query.filter_by(user_id=current_user().id).first(); q=q.filter_by(worker_id=w.id) if w else q.filter_by(id=-1)
        return jsonify(items=[{'id':a.id,'worker':Worker.query.get(a.worker_id).full_name,'check_in':a.check_in.isoformat(),'check_out':a.check_out.isoformat() if a.check_out else None,'status':a.status} for a in q.all()])
    @app.get('/api/verification/pending')
    @auth_required('admin')
    def pending(): return jsonify(items=[worker_json(w) for w in Worker.query.filter_by(verification_status='Pending').all()])
    @app.post('/api/verification/<int:wid>/approve')
    @auth_required('admin')
    def approve(wid):
        w=Worker.query.get_or_404(wid); w.verification_status='Verified'; db.session.commit(); return jsonify(worker=worker_json(w))
    @app.post('/api/verification/<int:wid>/reject')
    @auth_required('admin')
    def reject(wid):
        w=Worker.query.get_or_404(wid); w.verification_status='Rejected'; db.session.commit(); return jsonify(worker=worker_json(w))
    @app.get('/api/anomalies')
    @auth_required('admin')
    def anomalies(): return jsonify(items=[{'id':a.id,'worker':Worker.query.get(a.worker_id).full_name if a.worker_id and Worker.query.get(a.worker_id) else 'Unknown','type':a.anomaly_type,'severity':a.severity,'score':a.score,'reason':a.reason,'resolved':a.resolved,'created_at':a.created_at.isoformat()} for a in AnomalyAlert.query.order_by(AnomalyAlert.created_at.desc()).limit(200).all()])
    @app.get('/api/anomalies/statistics')
    @auth_required('admin')
    def anomaly_stats(): return jsonify(total=AnomalyAlert.query.count(),open=AnomalyAlert.query.filter_by(resolved=False).count(),by_severity={s:AnomalyAlert.query.filter_by(severity=s,resolved=False).count() for s in ('Critical','High','Medium','Low')})
    @app.patch('/api/anomalies/<int:aid>/resolve')
    @auth_required('admin')
    def resolve(aid): a=AnomalyAlert.query.get_or_404(aid); a.resolved=True; db.session.commit(); return jsonify(message='Alert resolved')
    @app.get('/api/notifications')
    @auth_required()
    def notifications(): return jsonify(items=[{'id':n.id,'message':n.message,'read':n.read,'created_at':n.created_at.isoformat()} for n in Notification.query.filter_by(user_id=current_user().id).order_by(Notification.created_at.desc()).limit(50)])
    @app.errorhandler(404)
    def not_found(e): return jsonify(error='Resource not found'),404
    @app.errorhandler(413)
    def too_large(e): return jsonify(error='Upload exceeds 5 MB limit'),413
    return app

app=create_app()
