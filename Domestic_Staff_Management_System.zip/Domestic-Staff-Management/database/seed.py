from datetime import date, datetime, timedelta
from backend.app import create_app
from backend.database import db
from backend.models import *
app=create_app()
with app.app_context():
    db.drop_all(); db.create_all()
    c=Community(name='Greenview Residency',address='Hyderabad, Telangana'); db.session.add(c); db.session.flush()
    apartments=[]
    for b,u in [('A','101'),('A','102'),('B','201'),('B','202')]:
        a=Apartment(community_id=c.id,building=b,unit=u); db.session.add(a); apartments.append(a)
    def user(name,email,password,role,phone):
        x=User(name=name,email=email,password_hash='',role=role,phone=phone); x.set_password(password); db.session.add(x); db.session.flush(); return x
    admin=user('Platform Admin','admin@demo.local','Admin@123','admin','9000000001')
    residents=[]
    for i in range(3):
        u=user(['Aarav Resident','Meera Resident','Kiran Resident'][i],f'resident{i+1}@demo.local','Resident@123','resident',f'900000000{i+2}')
        r=Resident(user_id=u.id,apartment_id=apartments[i].id); db.session.add(r); residents.append(r)
    for i in range(2):
        u=user(f'Security Guard {i+1}',f'guard{i+1}@demo.local','Guard@123','guard',f'900000001{i}')
        db.session.add(SecurityGuard(user_id=u.id,shift='Day' if i==0 else 'Night'))
    workers=[]
    jobs=['Housekeeper','Cook','Driver','Babysitter','Gardener']
    for i in range(5):
        w=Worker(full_name=['Anita Rao','Lakshmi Devi','Ravi Kumar','Sana Begum','Mohan Das'][i],phone=f'910000000{i}',age=30+i,occupation=jobs[i],address='Demo address, Hyderabad',id_document_type='Aadhaar (masked)',id_document_last4=f'{1000+i}',verification_status='Verified' if i<4 else 'Pending')
        db.session.add(w); db.session.flush(); workers.append(w)
        if i<4:
            r=residents[i%3]; a=WorkerAssignment(worker_id=w.id,resident_id=r.id,apartment_id=r.apartment_id,start_date=date.today()); db.session.add(a); db.session.flush()
            db.session.add(Schedule(assignment_id=a.id,weekday=date.today().weekday(),start_time='08:00',end_time='10:00',valid_from=date.today()))
            if i<3:
                db.session.add(Attendance(worker_id=w.id,resident_id=r.id,check_in=datetime.now()-timedelta(hours=2),check_out=datetime.now()-timedelta(hours=1)))
                db.session.add(EntryExitLog(worker_id=w.id,resident_id=r.id,event_type='ENTRY',authorized=True,event_time=datetime.now()-timedelta(hours=2)))
                db.session.add(EntryExitLog(worker_id=w.id,resident_id=r.id,event_type='EXIT',authorized=True,event_time=datetime.now()-timedelta(hours=1)))
        db.session.add(VerificationDocument(worker_id=w.id,document_type='Identity',status=w.verification_status))
    # Intentional anomaly sample: unapproved worker at 01:15
    db.session.add(EntryExitLog(worker_id=workers[4].id,resident_id=None,event_type='ENTRY',authorized=False,event_time=datetime.now().replace(hour=1,minute=15)))
    db.session.add(AnomalyAlert(worker_id=workers[4].id,anomaly_type='UNAUTHORIZED_ACCESS',severity='Critical',score=1.0,reason='Demo alert: unverified worker attempted entry at an unusual hour.'))
    db.session.commit()
    print('Demo data created. Admin: admin@demo.local / Admin@123')
