# HavenDesk — Domestic Staff Management System

A locally runnable Flask + SQLite full-stack application for residential communities to manage domestic workers, resident assignments, schedules, gate entry/exit, attendance, verification decisions and intelligent access alerts. The default database is SQLite for frictionless setup; SQLAlchemy supports switching to MySQL with a `DATABASE_URL` change.

## Problem, objectives and scope
Apartment communities often maintain staff identity, schedules and gate logs in disconnected registers. HavenDesk centralizes worker profiles, resident relationships, approval state, work schedules, attendance and gate events. It supports four roles: admin, resident, security guard and worker. Identity-document status means **reviewed by the community admin only**; there is no government database verification integration.

## Features
- Session login, password hashing, role-based API authorization.
- Worker CRUD, search, filters, masked identity-document suffix and admin approval/rejection.
- Residents and apartment records; worker-to-resident assignments.
- Schedule creation, cancellation and overlapping-time conflict prevention.
- Gate entry/exit logs, attendance creation, currently-inside view and resident notifications.
- Rule-based anomaly detection plus optional Pandas/IsolationForest history scoring.
- Dashboard metrics, alert review/resolution, pagination and API tests.
- Responsive Bootstrap dashboard. Demo data is fictional.

## Stack and architecture
- UI: HTML5, CSS3, JavaScript, Bootstrap 5.
- API: Python 3.11+ / Flask, SQLAlchemy ORM, signed cookie session.
- DB: SQLite by default; MySQL supported by SQLAlchemy driver configuration.
- Intelligence: Python rules, Pandas and scikit-learn IsolationForest.

```mermaid
flowchart LR
  UI[Browser dashboard] -->|JSON / HTTPS in deployment| API[Flask REST API]
  API --> AUTH[Auth & RBAC]
  API --> WORK[Worker / Resident service]
  API --> PLAN[Schedule service]
  API --> ACCESS[Attendance & Access service]
  ACCESS --> DETECT[Anomaly detection service]
  DETECT --> ALERT[(Anomaly alerts)]
  AUTH --> DB[(Relational database)]
  WORK --> DB
  PLAN --> DB
  ACCESS --> DB
  API --> NOTIFY[Notification service]
  NOTIFY --> DB
```

The modules are separated by domain (models, services and route handlers in the Flask application). They communicate through internal service functions and the same database transaction boundary. REST endpoints are the service contract; these modules can be extracted into separate processes later. This local edition intentionally avoids requiring Redis or paid APIs.

## ER model and normalization (CO1)
```mermaid
erDiagram
 USERS ||--o| RESIDENTS : profile
 USERS ||--o| SECURITY_GUARDS : profile
 USERS ||--o| WORKERS : optional_login
 COMMUNITIES ||--o{ APARTMENTS : contains
 APARTMENTS ||--o{ RESIDENTS : houses
 WORKERS ||--o{ WORKER_ASSIGNMENTS : assigned
 RESIDENTS ||--o{ WORKER_ASSIGNMENTS : employs
 APARTMENTS ||--o{ WORKER_ASSIGNMENTS : authorizes
 WORKER_ASSIGNMENTS ||--o{ SCHEDULES : schedules
 WORKERS ||--o{ ATTENDANCE : records
 RESIDENTS ||--o{ ATTENDANCE : receives
 WORKERS ||--o{ ENTRY_EXIT_LOGS : enters
 WORKERS ||--o{ VERIFICATION_DOCUMENTS : submits
 USERS ||--o{ NOTIFICATIONS : receives
 WORKERS ||--o{ ACCESS_REQUESTS : requests
 WORKERS ||--o{ ANOMALY_ALERTS : triggers
```

| Table | Purpose / relationships |
|---|---|
| users | Login identity, unique email, role and password hash. |
| communities | Residential community master. |
| apartments | Building/unit per community; unique community/building/unit. |
| residents | Resident profile linked one-to-one to a user and an apartment. |
| security_guards | Guard profile linked one-to-one to a user. |
| workers | Domestic worker profile, approval status and masked ID suffix. |
| worker_assignments | Many-to-many bridge between workers and residents, scoped to an apartment and date range. |
| schedules | Recurring weekday/time window for an assignment. |
| attendance | Actual check-in/check-out linked to worker, resident and guard. |
| entry_exit_logs | Immutable gate event history and authorization decision. |
| verification_documents | Document metadata and admin review history; file content is not exposed. |
| notifications | In-app notifications for a user. |
| access_requests | Temporary/permanent access request lifecycle storage. |
| anomaly_alerts | Detection type, severity, score, explanation and resolution status. |

The model separates user credentials from role-specific profiles and uses the assignment bridge for the worker/resident many-to-many relationship. Columns are atomic; non-key attributes depend on their table key; repeated relationships are moved into bridge/history tables (3NF-oriented). Foreign keys and unique constraints preserve referential integrity. Indexes target common lookup/filter columns.

## Database operations (CO2)
SQLAlchemy models create the schema at application startup. Example SQL (SQLite syntax):
```sql
-- INSERT
INSERT INTO communities(name,address) VALUES ('Greenview Residency','Hyderabad');
-- SELECT + WHERE + ORDER BY
SELECT full_name,occupation,verification_status FROM worker WHERE verification_status='Verified' ORDER BY full_name;
-- UPDATE
UPDATE worker SET availability='Unavailable' WHERE id=1;
-- DELETE: production-safe soft deactivation retains audit history
UPDATE worker SET availability='Inactive' WHERE id=1;
-- JOIN
SELECT w.full_name,u.name AS resident,a.building,a.unit
FROM worker w JOIN worker_assignment wa ON wa.worker_id=w.id
JOIN resident r ON r.id=wa.resident_id JOIN users u ON u.id=r.user_id
JOIN apartment a ON a.id=wa.apartment_id WHERE wa.active=1;
-- GROUP BY / aggregates
SELECT verification_status,COUNT(*) AS workers FROM worker GROUP BY verification_status;
SELECT worker_id,COUNT(*) AS gate_events,MAX(event_time) AS last_seen FROM entry_exit_log GROUP BY worker_id;
-- Transaction example
BEGIN; UPDATE worker SET verification_status='Verified' WHERE id=1;
INSERT INTO verification_document(worker_id,document_type,status) VALUES(1,'Identity','Verified'); COMMIT;
```

## API reference (CO3)
All JSON endpoints are under `/api`. Login establishes an HttpOnly session cookie; send the cookie on subsequent calls. Roles are enforced server-side.

| Method | Endpoint | Roles / purpose |
|---|---|---|
| POST | `/auth/register` | Public resident/worker self-registration |
| POST | `/auth/login`, `/auth/logout` | Login / logout |
| GET | `/auth/me` | Authenticated current identity |
| GET, POST | `/workers` | Admin/resident/guard list; admin/resident create |
| GET, PUT, DELETE | `/workers/<id>` | Read; admin update/deactivate |
| PATCH | `/workers/<id>/verify` | Admin verification status |
| GET, POST | `/residents` | Admin list/create |
| PUT, DELETE | `/residents/<id>` | Admin update/deactivate |
| POST | `/assignments` | Admin/resident assign worker |
| GET, POST | `/schedules` | Authenticated list; admin/resident create |
| PUT, DELETE | `/schedules/<id>` | Admin/resident update/cancel |
| POST | `/access/entry`, `/access/exit` | Admin/guard record movement |
| GET | `/access/logs`, `/access/currently-inside` | Admin/guard/resident logs; admin/guard inside list |
| GET | `/attendance/history` | Admin/resident/worker history |
| GET | `/verification/pending` | Admin pending queue |
| POST | `/verification/<id>/approve`, `/reject` | Admin decision |
| GET | `/anomalies`, `/anomalies/statistics` | Admin alerts and counts |
| PATCH | `/anomalies/<id>/resolve` | Admin resolve alert |
| GET | `/notifications` | Current user's notifications |
| GET | `/dashboard` | Role-aware dashboard metrics |

Responses use standard HTTP status codes (200, 201, 400, 401, 403, 404, 409, 413, 503). Validation errors return `{"error":"..."}`. Test using the browser UI or Postman; set `Content-Type: application/json` and retain cookies after login.

## Anomaly detection (CO5)
`anomaly_detection/detector.py` provides deterministic checks: unapproved entry, entry from 23:00–05:00, duplicate entry without a matching exit, no active assignment, repeated verification failures (3+), and schedule deviation of at least two hours. Each finding contains a type, severity, numeric score and human-readable reason. The access service persists each finding to `anomaly_alerts`. `score_history()` uses Pandas to construct hour/weekday/duration features and optional scikit-learn IsolationForest scoring when at least eight records exist; deterministic rules remain the reliable fallback. The detector never asserts identity authenticity from an external authority.

Demo anomaly: the seed inserts an unverified worker's overnight unauthorized entry and a Critical alert. Log in as admin → Security alerts to inspect and resolve it. For a live test, add a worker, leave it Pending, then log in as a guard and record an entry; it is recorded as unauthorized and creates an alert.

## Setup — Windows / VS Code
Requirements: Windows 10/11, VS Code, Python 3.11 or 3.12 (64-bit), and internet access for installing packages / Bootstrap CDN. No MySQL server or third-party API credentials required.

1. Extract `Domestic_Staff_Management_System.zip`.
2. Open VS Code → **File → Open Folder** → `Domestic-Staff-Management`.
3. Open **Terminal → New Terminal** (PowerShell), then run:
```powershell
cd Domestic-Staff-Management
py -3.11 -m venv venv
venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python database\seed.py
python run.py
```
If Python 3.11 is not installed, use `py -m venv venv` instead. If activation is blocked, for this terminal session only run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` and retry `venv\Scripts\Activate.ps1`; alternatively run `venv\Scripts\python.exe -m pip install -r requirements.txt`, then `venv\Scripts\python.exe database\seed.py` and `venv\Scripts\python.exe run.py` without activation.
4. Open **http://127.0.0.1:5000** in a browser.
5. Stop the server with **Ctrl+C** in the terminal. Restart with `python run.py` (database and demo data remain until reseeded).

`python database\seed.py` resets the local demo database and repopulates it. Do not run it if you need to retain your own records.

## Demo accounts
All passwords below are fictional demo credentials:

| Role | Email | Password |
|---|---|---|
| Admin | `admin@demo.local` | `Admin@123` |
| Resident 1 | `resident1@demo.local` | `Resident@123` |
| Resident 2 | `resident2@demo.local` | `Resident@123` |
| Resident 3 | `resident3@demo.local` | `Resident@123` |
| Guard 1 | `guard1@demo.local` | `Guard@123` |
| Guard 2 | `guard2@demo.local` | `Guard@123` |

Worker profiles are created for the five demo workers. A worker login is not seeded; workers can self-register through `POST /api/auth/register` with role `worker`.

## Testing (CO6)
```powershell
pytest -q
```
Tests cover health, unauthenticated access, login, worker creation/verification and role restrictions. Manual end-to-end walkthrough: admin login → Workers → add worker → approve → resident login and assign worker (assignment API) → create schedule → guard login → Entry & exit → record entry and exit → resident attendance history → admin Security alerts → resolve. For unauthorized anomaly testing, use a Pending worker or the pre-seeded demo alert.

## Security and production hardening
Passwords are Werkzeug PBKDF2 hashes; SQL is parameterized through SQLAlchemy; roles are checked on each protected API; cookies are HttpOnly/SameSite; upload size is capped. This evaluation build deliberately stores only document metadata and a masked last-four identifier, not raw ID numbers or uploaded files. Before internet deployment: set a strong random `SECRET_KEY`, use HTTPS, secure cookies, CSRF protection, rate limiting, audit logging, malware-scanned private object storage, backups, migrations, stricter resident data scoping, and a production WSGI server. Use MySQL by installing a compatible driver and setting `DATABASE_URL` (for example `mysql+pymysql://user:password@localhost/domestic_staff` after adding `pymysql`).

## Troubleshooting
- `py` not recognized: install Python 3.11+ and enable **Add Python to PATH**, then reopen VS Code.
- `ModuleNotFoundError`: activate the venv and rerun `pip install -r requirements.txt`.
- Port 5000 busy: stop the other process or change port in `run.py`.
- Login fails: rerun `python database\seed.py` (this resets demo data).
- Browser API errors: confirm server is running at `127.0.0.1:5000`; keep browser cookies enabled.
