import pytest
from backend.app import create_app
from backend.database import db
from backend.models import User, Worker
@pytest.fixture()
def client(tmp_path):
    app=create_app({'TESTING':True,'SQLALCHEMY_DATABASE_URI':f"sqlite:///{tmp_path/'test.db'}",'SECRET_KEY':'test'})
    with app.app_context():
        db.create_all(); u=User(name='Admin',email='admin@test.local',role='admin'); u.set_password('Admin@123'); db.session.add(u); db.session.commit()
    with app.test_client() as c: yield c
    with app.app_context(): db.drop_all()
def login(c): return c.post('/api/auth/login',json={'email':'admin@test.local','password':'Admin@123'})
def test_health_and_auth(client):
    assert client.get('/api/health').status_code==200
    assert client.get('/api/workers').status_code==401
    assert login(client).status_code==200
    assert client.get('/api/workers').status_code==200
def test_worker_create_verify(client):
    login(client)
    r=client.post('/api/workers',json={'full_name':'Demo Worker','phone':'9000000000','occupation':'Cook'})
    assert r.status_code==201
    wid=r.json['worker']['id']
    assert client.patch(f'/api/workers/{wid}/verify',json={'status':'Verified'}).status_code==200
def test_role_authorization(client):
    client.post('/api/auth/register',json={'name':'Resident','email':'r@test.local','password':'Resident@123','role':'resident'})
    client.post('/api/auth/login',json={'email':'r@test.local','password':'Resident@123'})
    assert client.get('/api/anomalies').status_code==403
