"""Hybrid rule-based + optional IsolationForest access anomaly detector."""
from datetime import datetime
import pandas as pd

def detect_event(event, worker, open_entries=0, recent_failures=0, scheduled_start=None, assigned=True):
    findings=[]; when=event.get('event_time') or datetime.utcnow(); hour=when.hour if isinstance(when,datetime) else datetime.fromisoformat(str(when)).hour
    if not event.get('authorized',False): findings.append(('UNAUTHORIZED_ACCESS','Critical',1.0,'Worker is not approved for normal community access.'))
    if event.get('event_type')=='ENTRY' and open_entries>0: findings.append(('DUPLICATE_CHECK_IN','High',0.9,'Worker already has an open entry; check-out is missing.'))
    if event.get('event_type')=='ENTRY' and (hour<5 or hour>=23): findings.append(('UNUSUAL_ENTRY_TIME','High',0.85,f'Entry at {hour:02d}:00 is outside the normal 05:00–23:00 window.'))
    if not assigned: findings.append(('UNEXPECTED_COMMUNITY_ACCESS','Critical',1.0,'No active worker assignment exists for this resident/apartment.'))
    if recent_failures>=3: findings.append(('REPEATED_FAILED_VERIFICATION','High',0.9,f'{recent_failures} failed verification attempts were recorded recently.'))
    if scheduled_start and event.get('event_type')=='ENTRY':
        delta=abs(hour-int(str(scheduled_start).split(':')[0]))
        if delta>=2: findings.append(('UNUSUAL_ATTENDANCE_PATTERN','Medium',0.65,f'Entry differs from scheduled start ({scheduled_start}) by about {delta} hours.'))
    return [{'type':t,'severity':s,'score':sc,'reason':r} for t,s,sc,r in findings]

def score_history(rows):
    """Optional unsupervised score; requires >= 8 rows, gracefully falls back."""
    if len(rows)<8: return [0.0]*len(rows)
    try:
        from sklearn.ensemble import IsolationForest
        frame=pd.DataFrame(rows); X=frame[['hour','weekday','duration_minutes']].fillna(0)
        model=IsolationForest(contamination=0.12,random_state=42); model.fit(X)
        return [round(float(-v),3) for v in model.decision_function(X)]
    except Exception: return [0.0]*len(rows)
