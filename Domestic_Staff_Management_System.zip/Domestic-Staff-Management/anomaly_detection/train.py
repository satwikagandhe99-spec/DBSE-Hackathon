from pathlib import Path
import pandas as pd
from detector import score_history

path=Path(__file__).with_name('sample_data.csv')
frame=pd.read_csv(path)
scores=score_history(frame.to_dict(orient='records'))
frame['anomaly_score']=scores
print(frame.to_string(index=False))
print('\nHigher positive scores indicate more unusual observations when IsolationForest is available.')
